import java.util.ArrayList;

public class Graph {
    int V;
    int A;
    Link [] adj;

}
