public class Vertex {
    int vertex;
}
