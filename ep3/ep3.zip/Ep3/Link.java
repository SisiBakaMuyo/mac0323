public class Link {
    Vertex val;
    Link next;
}
